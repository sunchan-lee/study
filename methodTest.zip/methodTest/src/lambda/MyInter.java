package lambda;

//@FunctionalInterface
//함수적 인터페이스 - 추상인터페이스가 하나다.
//즉 람다는 추상 인터페이스가 하나여야한다.
//생략해서 표현하기때문에 이름이 없어서 헷갈린다.
//이름을 쓰게되면 생략하는 의미가 없어서 하나만 허용한다.
public interface MyInter {
	
	public void run();
	//public void disp();

}

interface MyInter2{
	public void run(int a);
}
interface MyInter3{
	public int run(int a, int b);
}
interface MyInter4{
	public void run(int a, int b);
}

//테스트
interface MathOperation{
	public int run(int a, int b);
}

