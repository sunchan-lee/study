package lambda;

public class LambdaTest02 {
	public static void main (String [] args) {
		MyInter in1=()->{
			System.out.println("ㅎㅇ, 람다 처음?");
		};
		in1.run();
		
		MyInter2 in2=(a)->{
			System.out.println(a);
		};
		
		in2.run(10);
		
		//파라미터 변수가 1개이면 ()괄호 생략 가능
		MyInter2 in3=(a)->{
			System.out.println(a);
		};
		in3.run(20);
		//실행문도 1줄이면 {} 생략 가능
		MyInter2 in4=(a)->System.out.println(a);
		in4.run(30);
		
		//파라미터 변수 2개이상이면 ()는 필수
		MyInter3 obj=(a,b)->{return a+b;};
		//MyInter3 obj2=(a,b)->{return a+b;}; //{}생 략 불 가
		MyInter3 obj2=(a,b)-> a+b; //return키워드를 생략하면 {} 생 략 가 능
		
		//테스트 
		MathOperation add=(a, b)->a+b;
		System.out.println("덧셈 : " + add.run(50, 40));
		
		MathOperation sub=(a, b)->a-b;
		System.out.println("뺄셈 : " + sub.run(50, 40));
		
		MathOperation mul=(a, b)->a*b;
		System.out.println("곱셈 : " + mul.run(50, 40));
		
		MathOperation div=(a, b)->a/b;
		System.out.println("나눗셈 : " + div.run(80, 40));

	}
	

}
