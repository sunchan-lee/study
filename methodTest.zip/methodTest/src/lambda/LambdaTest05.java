package lambda;

import java.util.function.IntBinaryOperator;

public class LambdaTest05 {

	public static void main(String[] args) {
		
		IntBinaryOperator op=(a,b)->Calu.add(a, b);
		IntBinaryOperator op2=Calu::add;
		
		//메소드를 실행시키는 명령어.
		Calu calu=new Calu();
		IntBinaryOperator op3 = (a,b)->calu.plus(a,b);
		IntBinaryOperator op4 = calu::plus;

	}

}
