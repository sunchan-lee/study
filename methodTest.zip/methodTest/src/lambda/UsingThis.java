package lambda;

public class UsingThis {
	
	int outfield=10;
	int inField=100;
	
	class Inner{
		int inField=20;	
		void disp() {
			MyInter my=()->{
				int inField=30;
				System.out.println("outfield " + outfield);
				System.out.println("inField " + inField);
				//람다식 내부에서 this는 Inner 객체입니다.
				System.out.println("inField " + this.inField);
				System.out.println("inField " + UsingThis.this.inField);
			};
			my.run();
		}
	}

}
