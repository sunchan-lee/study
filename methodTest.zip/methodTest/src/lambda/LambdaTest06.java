package lambda;

import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

import methodTest.Entity;
import methodTest.ResponseDto;
class Member{
	private String id;
	private String name;
	
	public Member() {
		System.out.println("member실행");
	}

	public Member(String id) {
		this.id = id;
	}

	public Member(String id, String name) {
		this.id = id;
		this.name = name;
	}
	
}
public class LambdaTest06 {

	public static void main(String[] args) {
		//R apply(T t);
		//ResponseDto apply(T t);
		
		Function<String, Member>function=(t)->new Member(t);
		Function<String, Member>fun=Member::new;
		Member member1 = fun.apply("그린");
		
		//BiFunction<String, Member>function2=(t,u)->new Member(t,u);
		BiFunction<String, String, Member> fun2=Member::new;
		fun2.apply("그린", "no1");
		
		Function<String, ResponseDto> ent=(t)-> new ResponseDto();
		//Function<String, ResponseDto> ent2=ResponseDto::new;
		
		Consumer c;
		Supplier s;
		IntSupplier sl;
	

	}

}













