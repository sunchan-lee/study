package lambda;

public class Calu {
	
	//static 유
	public static int add(int a, int b) {
		return a+b;
	}
	
	//static 무 (인스턴스 메소드)
	public int plus(int a, int b) {
		return a+b;
	}

}
