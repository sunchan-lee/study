package lambda;

public class LambdaTest {
	public static void main (String [] args) {
		
		Runnable runnable1 = new Runnable() {
			//익명 구현 객체
			@Override
			public void run() {
			}
		};
		//람다식: 익명 함수를 생성하기 위한 식
		//객체지향언어보단, 함수지향 언어에 가까운 표현 방식, 코딩이 간결해진다.
		//											컬렉션 filter, map result 표현할때 쉽게 할수 있다.
		//오버라이드 생략, 바디 영역 생략.
		Runnable runable2=()->{};
		
		//this expression must be a functional interface
		MyInter my2=()->{};
		MyInter my = new MyInter() {
			
			@Override
			public void run() {
				
			}
		};
	}

}
