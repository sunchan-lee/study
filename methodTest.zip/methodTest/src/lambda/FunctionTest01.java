package lambda;

import java.util.Arrays;
import java.util.List;
import java.util.function.ToIntFunction;

class Student{
	private String name;
	private int kor;
	private int eng;
	private int mat;
	
	
	public Student(String name, int kor, int eng, int mat) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.mat = mat;
	}


	public String getName() {
		return name;
	}
	public int getKor() {
		return kor;
	}
	public int getEng() {
		return eng;
	}
	public int getMat() {
		return mat;
	}
}

public class FunctionTest01 {
	
	private static List<Student> list=Arrays.asList(
			new Student("이름1",90,88,96),
			new Student("이름2",80,60,50),
			new Student("이름3",85,92,86)
			);
	
	public static double avg(ToIntFunction<Student> function) {
		int sum=0;
		for(Student student:list) {
			sum+=function.applyAsInt(student);
		}
		double avg= (double)sum/list.size();
		return avg;
	}

	public static void main(String[] args) {
		
		System.out.println("국어 평균 : " + avg(s->s.getKor()));
		System.out.println("영어 평균 : " + avg(s->s.getEng()));
		System.out.println("수학 평균 : " + avg(s->s.getMat()));

	}

}
