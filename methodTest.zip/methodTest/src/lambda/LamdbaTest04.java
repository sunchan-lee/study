package lambda;

public class LamdbaTest04 {

	public static void main(String[] args) {
		
		MyInter3 obj=(a,b)->a+b;
		
		MyInter3 obj2=(a,b)->Math.max(a, b);
		int result = obj2.run(10, 20);
		System.out.println(result);
		
		//max()파라미터 변수가 int형 2개를 필요하고, 리턴도 int
		//가장 큰 값
		MyInter3 obj3=Math::max;
		
		//min()파라미터 변수가 int형 2개를 필요하고, 리턴도 int
		MyInter3 obj4=Math::min;

	}

}
