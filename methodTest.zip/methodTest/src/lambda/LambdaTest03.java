package lambda;

public class LambdaTest03 {
	public static void main(String [] args) {
		
		
		UsingThis outer = new UsingThis();
		UsingThis.Inner inner= outer.new Inner();
		inner.disp();
	}

}
