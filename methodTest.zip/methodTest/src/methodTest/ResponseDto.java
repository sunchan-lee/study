package methodTest;

import java.time.LocalDateTime;
//DB에 있는 정보를 페이지로 전송하기위한 목적
//db에서 응답해서 페이지로 보낸다.
//리스폰스
//JPA: entity의 정보를 페이지로 전송하기 위한 목적
public class ResponseDto {
	private int no;
	private String text;
	private int read;
	private LocalDateTime date;
	
	public ResponseDto() {
		//메소드 목적 - entity의 정보를 dto
		//map()활용가능 람다식 활용 가능 ResponseDto::new
	}
	
	//필수적으로 준비를 해주자.
	//생성자 통해서 처리한다.
	public ResponseDto(Entity entity) {
		this.no = entity.getNo();
		this.text = entity.getText();
		this.read = entity.getRead();
		this.date = entity.getDate();
	}



	//게터 세터 먼저
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getRead() {
		return read;
	}
	public void setRead(int read) {
		this.read = read;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	
	
	
	


	
	
	
}
