package methodTest;

//웹에서 요청된 데이터 -> db까지
//웹에서 요청해서 db로 보낸다.
//jpa dto -> entity


public class RequestDto {
	private String text;
	private int read;

	public int getRead() {
		return read;
	}
	public void setRead(int read) {
		this.read = read;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	//dto 클래스의 정보를 entity 멤버에 저장한다.
	public Entity toEntity() {
		//dto 클래스를 entity로 바꾼다.
		Entity entity = new Entity(text, read);
		return entity;
	}
	
	
}
