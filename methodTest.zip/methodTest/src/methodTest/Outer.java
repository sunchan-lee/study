package methodTest;

public class Outer {
	//빌더 패턴 엔티티, dto에도 활용할수 있다.
	//빌더 패턴은 inner class로 구성된다.
	//outer class의 보조적인 역할
	
	int no;
	String text;
	
	public Outer() {}

	public Outer(int no, String text) {
		this.no = no;
		this.text = text;
	}
	///////////////////////////////////////////////////////
	
	public static OuterBuilder builder() {
		return new OuterBuilder();
	}
	///////////////////////////////////////////////////////
	static class OuterBuilder{
		int no;
		String text;
		//no 필드 세팅, 그 이후 클래스 리턴.
		public OuterBuilder no(int no) {
			this.no=no;
			return this;
		}
		//text도 no와 똑같이 세팅, 그 이후 클래스 리턴
		public OuterBuilder text(String text) {
			this.text=text;
		return this;
		}
		
		public Outer build() {
			return new Outer(no, text);
		}
		
		
	}
	
	
	
	
	
	
	

}
