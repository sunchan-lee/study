package methodTest;

import methodTest.Outer.OuterBuilder;

public class MainTest {

	public static void main(String[] args) {
		OuterBuilder inner = Outer.builder();
		Outer outer = inner.build();
		
		Outer obj = Outer.builder().build();
		
		System.out.println(obj.toString());
		System.out.println(obj);
		
		
		Outer obj2 = Outer.builder().no(100).text("문자열").build();
		System.out.println(obj2);
		
		Outer obj3 = Outer.builder().no(300).build();
		System.out.println(obj3);
	}

}
