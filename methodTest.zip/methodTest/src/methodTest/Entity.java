package methodTest;

import java.time.LocalDateTime;

public class Entity {
	private int no;
	private String text;
	private int read;
	private LocalDateTime date;
	
	
	//text, read 데이터를 변경후에, 변경된 객체를 리턴한다.
	private Entity update(RequestDto dto) {
		text=dto.getText();
		read=dto.getRead();
		return this;
	}
	
	public Entity() {}
	
	public Entity(String text, int read) {
		this.text = text;
		this.read = read;
	}
	
	//자바에서는 어노테이션을 사용할수 없다.
	/* @Builder */
	public Entity(int no, String text, int read, LocalDateTime date) {
		this.no = no;
		this.text = text;
		this.read = read;
		this.date = date;
	}

	public int getRead() {
		return read;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public int getNo() {
		return no;
	}
	public String getText() {
		return text;
	}
	
	
	
}
