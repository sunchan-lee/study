package map;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

class Student{
	
	public Student() {}
	
	int stdno;
	String name;
	
	public Student(int stdno, String name) {
		super();
		this.stdno = stdno;
		this.name = name;
	}
}

public class MapTest {
	public Map<String, Object> map=new HashMap<String, Object>();
	
	public void addObject(String name, Object obj) {
		map.put(name, obj);
	}
	public void setAttribute(String name, Object obj) {
		map.put(name, obj);
	}
	public Object getAttribute(String name) {
		return map.get(name);
	}

	public static void main(String[] args) {
		
		List<Student> list = new Vector<Student>();
		list.add(new Student(1, "aaaa"));
		list.add(new Student(2, "bbbbb"));
		list.add(new Student(3, "cccccc"));
		
		MapTest request = new MapTest();
		
		request.setAttribute("listData", list);
		
		List<Student> result=(List<Student>) request.getAttribute("listData");
		for(Student s:result) {
			System.out.println(s.stdno +" : " + s.name);
		}
		

	}

}
