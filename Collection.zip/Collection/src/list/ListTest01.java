package list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

class Student{
	
	public Student() {}
	
	int stdno;
	String name;
	
	public Student(int stdno, String name) {
		super();
		this.stdno = stdno;
		this.name = name;
	}
	
	
}

public class ListTest01 {

	public static void main(String[] args) {
		
		//		 <String> 을 넣으면 문자열만 넣을수 있다.
		//ArrayList<String> list = new ArrayList<>();
		
		//		 <Student> 을 넣으면 Student 객체를 사용한다.
		List<Student> list = new ArrayList<>();
		list.add(new Student(1, "1번"));				//순차적 삽입
		list.add(new Student(2, "2번"));
		list.add(new Student(3, "3번"));
		
		List<String> result=list.stream()
			.map(s->s.name)
			.collect(Collectors.toList());
		
		result.stream().forEach(n->{
			System.out.println(n);
		});
		System.out.println("=============================");
		
		
		List<Integer> result2=list.stream()
				.map(s->s.stdno)
				.collect(Collectors.toList());
		
		result2.stream().forEach(n->{
			System.out.println(n);
		});

		
		
		
		System.out.println(list.size());
		for(int i=0; i<list.size(); i++) {
			Student student = list.get(i);
			System.out.println(student.stdno + " : " + student.name);
		}
		
		list.remove(1);
		
		System.out.println("========================================");
		for(Student student:list) {
			System.out.println(student.stdno + " : " + student.name);			
		}
		
		list.add(new Student(2, "새로운 이름 2")); //중간에 삽입
		System.out.println("========================================");
		list.stream().forEach(s->{
			System.out.println(s.stdno + " : " + s.name);
		});
	
		Map<String, List<Student>> map = new HashMap<String, List<Student>>();
		map.put("list", list);
		List<Student> list_return=map.get("list");
		
		Map<String, List<Student>> map2 = new HashMap<String, List<Student>>();
		map.put("aaa", list);
		List<Student> list_return2=map2.get("aaa");

	}
	
	


	
	
	

}
