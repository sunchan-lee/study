package list;

import java.util.List;
import java.util.Vector;

public class ListTest02 {
	
	public static void main(String [] args) {
		
		List<Board> list = new Vector<>();
		
		list.add(new Board("제목1", "내용1", "작성자1"));
		list.add(new Board("제목2", "내용2", "작성자3"));
		
		
		//Board board = list.get(0);
		
		//System.out.println(board.getSubject());
		//System.out.println(board.getContent());
		//System.out.println(board.getWriter());
		
		for(Board b : list) {
			
		}
		//변수명은 마음대로 만들어도 된다.
		list.stream().forEach((e)->{
			System.out.println(e);
		});
	}

}
